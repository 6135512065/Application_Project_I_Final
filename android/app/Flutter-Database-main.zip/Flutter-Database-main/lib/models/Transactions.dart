class Transactions{
  String title;//ชื่อรายการ
  double amount;//จำนวนเงิน
  DateTime date;//วันที่ เวลา บันทึกรายการ

  Transactions({this.title,this.amount,this.date});
}