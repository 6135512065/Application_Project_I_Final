package com.example.flutter_database

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
